import java.awt.print.Book;

public class seller{
	private int accountNum;  //5 digits
	private float credit;
	private boolean[] listedItems = new boolean[5]; //this will initialize all values to false
	
	
	public seller(int accountNum, float credit){
		this.accountNum = accountNum;
		this.credit = credit;
	}
	public void listABook(String ISBN, String condition, String title, String year, String format, String publisher, float price){
			book.class
		}
	//}
		
	
	public void removeBook(String ISBN){
		System.out.println("Removed book: " + title);
	}
	}
}
