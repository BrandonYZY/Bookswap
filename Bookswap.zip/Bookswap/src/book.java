
public class book {
		private String ISBN;
		private String condition;
		private String title; 
		private String year;
		private String format;
		private String publisher;
		private static int stock = 0;  //static adds additional books of same ISBN;
		public float price;
		
		public book(String ISBN, String condition, String title, String year, String format, String publisher, float price){
			this.ISBN = ISBN;
			this.condition = condition;
			this.title = title;
			this.year = year;
			this.format = format;
			this.publisher = publisher;
			this.price = price;
			this.stock++;
			}
		
		
		
		public static void status(){
			if (stock > 0) System.out.println("In stock");
			else System.out.println("Out of stock");			
		}
		
		
		public void displayInfo(){
			System.out.println("ISBN: " + ISBN);
			System.out.println("Condition: " + condition);
			System.out.println("Title: " + title);
			System.out.println("Year: " + year);
			System.out.println("Format: " + format);
			System.out.println("Publisher: " + publisher);
			System.out.println("Price: " + price);
			System.out.println("Stock: " + stock);
			
			
		}
		
		
} 