
public class buyer {
	private int accountNum;			//5 digits 
	private float credit;
	
}
